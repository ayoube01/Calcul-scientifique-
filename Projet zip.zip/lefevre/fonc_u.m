function u=fonc_u(x,y);
u=1+sin((pi/2)*x)+x.*(x-4)*cos((pi/2)*y);
