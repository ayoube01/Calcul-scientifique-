function y=f(x)
y=x*x;
return 