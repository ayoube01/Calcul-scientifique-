function uE=fonc_uE(x,y);
uE=ones(length(x),1);