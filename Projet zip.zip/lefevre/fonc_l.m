function f=fonc_l(x,y)
f=ones(length(x),1);