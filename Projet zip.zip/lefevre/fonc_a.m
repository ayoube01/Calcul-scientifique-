function f=fonc_a(x,y)
f=10^8;